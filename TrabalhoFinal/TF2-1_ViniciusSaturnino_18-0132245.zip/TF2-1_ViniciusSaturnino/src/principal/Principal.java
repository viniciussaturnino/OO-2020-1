package principal;

import dados.Grupo;
import saida.TelaPrincipal;

public class Principal {
	public static void main(String[] args) {
		TelaPrincipal init = new TelaPrincipal(new Grupo());
		init.setVisible(true);
	}
}
