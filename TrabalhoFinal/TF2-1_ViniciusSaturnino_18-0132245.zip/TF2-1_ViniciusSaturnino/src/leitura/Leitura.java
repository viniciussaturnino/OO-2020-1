package leitura;

import java.util.Scanner;

import javax.swing.JOptionPane;

public class Leitura {
	public static String getString(String mensagem, String titulo) {
		return (JOptionPane.showInputDialog(null, mensagem, titulo, JOptionPane.QUESTION_MESSAGE).trim());
	}

	public static int getInt(String mensagem, String titulo) {
		return Integer
				.parseInt(JOptionPane.showInputDialog(null, mensagem, titulo, JOptionPane.QUESTION_MESSAGE).trim());
	}

	@SuppressWarnings("resource")
	public static int getInt() {
		return new Scanner(System.in).nextInt();
	}

	@SuppressWarnings("resource")
	public static String getString() {
		return new Scanner(System.in).nextLine().trim();
	}

	@SuppressWarnings("resource")
	public static char getValidacao() {
		return new Scanner(System.in).next().toUpperCase().trim().charAt(0);
	}
}
