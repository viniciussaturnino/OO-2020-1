package saida;

import java.awt.Button;
import java.awt.Color;
import java.awt.Font;
import java.awt.SystemColor;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JLabel;
import javax.swing.JPanel;

import dados.Grupo;

@SuppressWarnings("serial")
public class TelaListagem extends JPanel {
	private JLabel lblListar = new JLabel("LISTAR USU�RIOS");
	private JLabel lblListarP = new JLabel("Para listar todos os usu�rios aperte o bot�o");
	private Button btnListar = new Button("Listar");

	public TelaListagem(Grupo grupo) {
		setBackground(SystemColor.menu);
		setBounds(0, 0, 650, 650);
		setLayout(null);

		lblListar.setFont(new Font("Roboto Cn", Font.PLAIN, 50));
		lblListar.setForeground(new Color(153, 0, 204));
		lblListar.setBounds(192, 110, 370, 50);
		add(lblListar);

		lblListarP.setFont(new Font("Roboto Lt", Font.PLAIN, 23));
		lblListarP.setBounds(150, 181, 464, 30);
		add(lblListarP);

		btnListar.setFont(new Font("Roboto Lt", Font.PLAIN, 18));
		btnListar.setForeground(new Color(255, 255, 255));
		btnListar.setBackground(new Color(153, 0, 204));
		btnListar.setBounds(315, 248, 146, 57);
		btnListar.addMouseListener(new MouseListener() {
			public void mouseReleased(MouseEvent e) {
				btnListar.setBackground(new Color(51, 0, 51));
			}

			public void mousePressed(MouseEvent e) {
				btnListar.setBackground(new Color(92, 92, 92));
			}

			public void mouseExited(MouseEvent e) {
				btnListar.setBackground(new Color(153, 0, 204));
			}

			public void mouseEntered(MouseEvent e) {
				btnListar.setBackground(new Color(51, 0, 51));
			}

			public void mouseClicked(MouseEvent e) {
				Saida.mostraDados(grupo);
			}
		});
		add(btnListar);
	}

}
