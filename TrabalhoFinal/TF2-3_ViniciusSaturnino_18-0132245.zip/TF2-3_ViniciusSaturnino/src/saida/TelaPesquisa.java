package saida;

import javax.swing.JPanel;
import java.awt.SystemColor;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.ImageIcon;
import javax.swing.JLabel;

import java.awt.Button;
import java.awt.Color;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.border.LineBorder;

@SuppressWarnings("serial")
public class TelaPesquisa extends JPanel {
	private JTextField txtNomePesquisa;
	private JLabel lblPesquisa = new JLabel("PESQUISA");
	private JLabel lblPerguntaPesquisa = new JLabel("Digite o nome a ser pesquisado");
	private JLabel lblSearchIcon = new JLabel("");
	private Button btnPesquisa = new Button("Pesquisar");

	public TelaPesquisa() {
		setBackground(SystemColor.menu);
		setBounds(0, 0, 650, 650);
		setLayout(null);

		lblPesquisa.setFont(new Font("Roboto Cn", Font.PLAIN, 50));
		lblPesquisa.setForeground(new Color(153, 0, 204));
		lblPesquisa.setBounds(288, 90, 217, 50);
		add(lblPesquisa);

		lblPerguntaPesquisa.setFont(new Font("Roboto Lt", Font.PLAIN, 23));
		lblPerguntaPesquisa.setBounds(230, 182, 329, 50);
		add(lblPerguntaPesquisa);

		txtNomePesquisa = new JTextField();
		txtNomePesquisa.setBounds(176, 248, 436, 30);
		txtNomePesquisa.setBorder(new LineBorder(new Color(153, 0, 204), 1));
		add(txtNomePesquisa);
		txtNomePesquisa.setColumns(10);

		lblSearchIcon.setIcon(new ImageIcon(TelaPrincipal.class.getResource("/imagens/search_purple.png")));
		lblSearchIcon.setBounds(616, 248, 24, 30);
		add(lblSearchIcon);

		btnPesquisa.setFont(new Font("Roboto Lt", Font.PLAIN, 18));
		btnPesquisa.setForeground(new Color(255, 255, 255));
		btnPesquisa.setBackground(new Color(153, 0, 204));
		btnPesquisa.setBounds(323, 305, 146, 57);
		btnPesquisa.addMouseListener(new MouseListener() {
			public void mouseReleased(MouseEvent e) {
				btnPesquisa.setBackground(new Color(51, 0, 51));
			}

			public void mousePressed(MouseEvent e) {
				btnPesquisa.setBackground(new Color(92, 92, 92));
			}

			public void mouseExited(MouseEvent e) {
				btnPesquisa.setBackground(new Color(153, 0, 204));
			}

			public void mouseEntered(MouseEvent e) {
				btnPesquisa.setBackground(new Color(51, 0, 51));
			}

			public void mouseClicked(MouseEvent e) {

			}
		});
		add(btnPesquisa);
	}
}
